package com.envc;

import com.envc.controller.ProjectController;
import com.envc.dao.entity.ProjectEntity;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.apache.log4j.Logger;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
class EnvcApplicationTests1 {
    @Resource
    ProjectController projectController = new ProjectController();
    Logger log = Logger.getLogger(EnvcApplicationTests.class);
    @Test
    public void queryProjectList(){
        ProjectEntity ProjectEntity = new ProjectEntity();
//        ProjectEntity.setProjectName("sssss");
        projectController.queryProjectList(ProjectEntity);
    }

    @Test
    public void insert(){
        ProjectEntity projectEntity=new ProjectEntity();
        projectEntity.setUserId("1");
        projectEntity.setProjectContent("这是一个项目");
        projectEntity.setCreatedBy("it");
        projectEntity.setProjectName("项目");
        projectEntity.setProjectContent("fhbjnk");
        projectController.addProject(projectEntity);
        projectController.deleteProject(projectEntity);
    }

    @Test
    public void deleteProjectByName(){
        ProjectEntity ProjectEntity = new ProjectEntity();
//        ProjectEntity.setId("275");
        ProjectEntity.setId("02a82531d07947b3adef1b4d8469c523");
        projectController.deleteProject(ProjectEntity);
    }


    @Test
    public void updateByPrimaryKeySelective(){
        ProjectEntity projectEntity = new ProjectEntity();
//        projectEntity.setId("02a82531d07947b3adef1b4d8469c523");
        projectEntity.setId("1");
        projectEntity.setProjectName("项目一");
        projectEntity.setProjectContent("一个项目");
        projectController.modifyProjectInfo(projectEntity);
    }

}
