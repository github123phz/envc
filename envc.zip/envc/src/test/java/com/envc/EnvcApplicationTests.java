package com.envc;

import com.envc.controller.UserController;
import com.envc.dao.entity.UserEntity;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
class EnvcApplicationTests {
    @Resource
    UserController userController = new UserController();

    @Test
    public void queryUserList(){
        UserEntity userEntity = null;
//        UserEntity userEntity = new UserEntity();
//        userEntity.setUsername("ssssui");
//        userEntity.setUsername("admin");
        userController.queryUserList(userEntity);
    }

    @Test
    public void selectUserInfo(){
        UserEntity userEntity = new UserEntity();
        userEntity.setUsername("admin");
        userEntity.setPassword("00000");
        userController.userLogin(userEntity);
    }
    @Test
    public void insert(){
        UserEntity userEntity = new UserEntity();
        userEntity.setPassword("123456");
        userController.addUser(userEntity);
        userController.deleteUser(userEntity);
    }

    @Test
    public void deleteUserById(){
        UserEntity userEntity = new UserEntity();
        userEntity.setId("07a6e55a49dd4a378477135b2b980bb4");
//        userEntity.setUsername("aaaaa");
        userController.deleteUser(userEntity);
    }

    @Test
    public void modifyUser(){
        UserEntity userEntity = new UserEntity();
        userEntity.setId("22c08beb47a64894b293fabeecf9bd68");
        userEntity.setUsername("bbbbb");
        userEntity.setPassword("123");
        userEntity.setCreatedBy("111");
        userController.modifyUser(userEntity);
    }
}