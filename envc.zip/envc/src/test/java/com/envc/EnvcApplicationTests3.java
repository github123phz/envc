package com.envc;

import com.envc.controller.OptionController;
import com.envc.controller.QuestionController;
import com.envc.controller.TongjiController;
import com.envc.dao.entity.OptionEntity;
import com.envc.dao.entity.QuestionEntity;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class EnvcApplicationTests3 {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    QuestionController questionController =  new QuestionController();
    @Autowired
    OptionController optionController=new OptionController();

    @Test
    public void testQueryProjectList() throws Exception {
        String shijuanid = "ABC123";

        RequestBuilder request = get("/tongji/index")
                .param("shijuanid", shijuanid)
                .accept(MediaType.TEXT_HTML);

        mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();
    }

    @Test
    public void queryQuestionList(){
        QuestionEntity questionEntity = new QuestionEntity();
        questionController.queryQuestionList(questionEntity);
    }

    @Test
    public void queryOptionList(){
        OptionEntity optionEntity = new OptionEntity();
        optionController.queryOptionList(optionEntity);
    }

    @Test
    public void queryProjectListTestWithCorrectId() {
        TongjiController controller = new TongjiController();
        String shijuanid = "123";
        String result = controller.queryProjectList(shijuanid);
        assertEquals("/pages/tongji/index", result);
    }

    @Test
    public void queryProjectListTestWithNullId() {
        TongjiController controller = new TongjiController();
        String shijuanid = null;
        String result = controller.queryProjectList(shijuanid);
        assertEquals("/pages/tongji/index", result);
    }

    @Test
    public void queryProjectListTestWithEmptyId() {
        TongjiController controller = new TongjiController();
        String shijuanid = "";
        String result = controller.queryProjectList(shijuanid);
        assertEquals("/pages/tongji/index", result);
    }

    @Test
    public void queryProjectListTestWithInvalidId() {
        TongjiController controller = new TongjiController();
        String shijuanid = "invalid";
        String result = controller.queryProjectList(shijuanid);
        assertEquals("/pages/tongji/index", result);
    }

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(new TongjiController()).build();
    }

    @Test
    public void queryProjectListTestWithId1() throws Exception {
        this.mockMvc.perform(get("/tongji/index").param("shijuanid", "1"))
                .andExpect(status().isOk())
                .andExpect(view().name("/pages/tongji/index"));
    }

    @Test
    public void queryProjectListTestWithId2() throws Exception {
        this.mockMvc.perform(get("/tongji/index").param("shijuanid", "2"))
                .andExpect(status().isOk())
                .andExpect(view().name("/pages/tongji/index"));
    }
}
