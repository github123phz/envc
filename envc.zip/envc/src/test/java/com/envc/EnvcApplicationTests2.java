package com.envc;

import com.envc.controller.*;
import com.envc.dao.entity.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EnvcApplicationTests2 {
    @Resource
    QuestionnaireController questionnaireController=new QuestionnaireController();
    QuestionController questionController =  new QuestionController();
    OptionController optionController=new OptionController();
    AnswerSheetController answerSheetController = new AnswerSheetController();
    AnswerController answerController = new AnswerController();
    PublishedController publishedController = new PublishedController();

    //新增问卷
    @Test
    public void insertQuestionnaire(){
        QuestionnaireEntity questionnaireEntity = new QuestionnaireEntity();
        questionnaireEntity.setTitle("我的问卷");
        questionnaireEntity.setDescription("好问卷");
        questionnaireController.addQuestionnaire(questionnaireEntity);
    }

    //新增问题
    @Test
    public void insertQuestion(){
        QuestionEntity questionEntity = new QuestionEntity();
        questionEntity.setContent("早上吃什么");
        questionController.addQuestion(questionEntity);
    }

    //新增选项
    @Test
    public void insertOption(){
        OptionEntity optionEntity = new OptionEntity();
        optionEntity.setContent("豆浆");
        optionController.addOption(optionEntity);
    }

    //查询问卷
    @Test
    public void queryQuestionnaireList(){
        QuestionnaireEntity questionnaireEntity = new QuestionnaireEntity();
        questionnaireController.queryQuestionnaireList(questionnaireEntity);
    }

    //查询问题
    @Test
    public void queryQuestionList(){
        QuestionEntity questionEntity = new QuestionEntity();
        questionController.queryQuestionList(questionEntity);
    }

    //查询选项
    @Test
    public void queryOptionList(){
        OptionEntity optionEntity = new OptionEntity();
        optionController.queryOptionList(optionEntity);
    }

    //查询答卷
    @Test
    public void queryAnswerSheetList(){
        AnswerSheetEntity answerSheetEntity = new AnswerSheetEntity();
        answerSheetController.queryAnswerSheetList(answerSheetEntity);
    }

    //查询某个问卷
    @Test
    public void selectQuestionnaire(){
        QuestionnaireEntity questionnaireEntity = new QuestionnaireEntity();
        questionnaireController.selectQuestionnaireList(questionnaireEntity);
    }

    //删除问卷
    @Test
    public void deleteQuestionnaireById(){
        QuestionnaireEntity questionnaireEntity = new QuestionnaireEntity();
        questionnaireEntity.setQuestionnaireId("0653ac855f2843aabf20ee862588c997");
        questionnaireController.deleteQuestionnaire(questionnaireEntity);
    }

    //查询答案
    @Test
    public void queryAnswerList(){
        AnswerEntity answer = new AnswerEntity();
        answerController.queryAnswerList(answer);
    }

    //发布问卷
    @Test
    public void publishQuestionnaire(){
        PublishedEntity publishedEntity = new PublishedEntity();
        publishedController.publishQuestionnaire(publishedEntity);
    }

    //查询已发布的问卷
    @Test
    public void queryPublishedQuestionnaire(){
        PublishedEntity publishedEntity = new PublishedEntity();
        publishedEntity.setId("c473a6c729f64eebbb95756268d3e472");
        publishedController.queryPublishedQuestionnaire(publishedEntity);
    }
}
