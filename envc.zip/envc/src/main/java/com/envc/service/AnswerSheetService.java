package com.envc.service;

import com.envc.dao.AnswerSheetEntityMapper;
import com.envc.dao.entity.AnswerSheetEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerSheetService {
    @Autowired
    AnswerSheetEntityMapper answerSheetEntityMapper;
    /**
     * 查询答卷
     * */
    public List<AnswerSheetEntity> queryAnswerSheetList(AnswerSheetEntity answerSheetEntity){
        List<AnswerSheetEntity> result=answerSheetEntityMapper.queryAnswerSheetList(answerSheetEntity);
        return result;
    }
}
