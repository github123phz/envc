package com.envc.service;

import com.envc.common.utis.UUIDUtil;
import com.envc.dao.PublishedEntityMapper;
import com.envc.dao.entity.PublishedEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PublishedService {
    @Autowired
    private PublishedEntityMapper publishedEntityMapper;

    /**
     * 发布问卷
     * */
    public int publishQuestionnaire(PublishedEntity publishedEntity){
        publishedEntity.setId(UUIDUtil.getOneUUID());
        System.out.println(publishedEntity.getQuestionnaireId());
        publishedEntity.setLink("http://127.0.0.1:8080/answer?questionnaireId="+publishedEntity.getQuestionnaireId() + "&token=" + UUIDUtil.getOneUUID());
        return publishedEntityMapper.publishQuestionnaire(publishedEntity);
    }

    public List<PublishedEntity> queryPublishedQuestionnaire(PublishedEntity publishedEntity){
        return publishedEntityMapper.queryPublishedQuestionnaire(publishedEntity);
    }
}
