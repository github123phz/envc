package com.envc.service;

import com.envc.common.utis.UUIDUtil;
import com.envc.dao.OptionEntityMapper;
import com.envc.dao.entity.OptionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OptionService {
    @Autowired
    private OptionEntityMapper optionEntityMapper;

    /**
     * 新增选项
     * */
    public int addOptionInfo(OptionEntity optionEntity){
        optionEntity.setOptionId(UUIDUtil.getOneUUID());
        int optionResult = optionEntityMapper.insert(optionEntity);
        if(optionResult != 0){
            return 3;
        }else {
            return optionResult;
        }
    }

    /**
     * 查询选项
     * */
    public List<OptionEntity> queryOptionList(OptionEntity optionEntity){
        return optionEntityMapper.queryOptionList(optionEntity);
    }

    public List<OptionEntity> queryOptionList2(String questionid){
        return optionEntityMapper.queryOptionList2(questionid);
    }

    public int getCountOption(String questionnaireId, String questionId, String optionId) {
        return optionEntityMapper.getCountOption( questionnaireId,  questionId,  optionId);
    }
}
