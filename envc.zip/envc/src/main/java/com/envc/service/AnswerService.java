package com.envc.service;

import com.envc.dao.AnswerEntityMapper;
import com.envc.dao.entity.AnswerEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {
    @Autowired
    private AnswerEntityMapper answerEntityMapper;

    /**
     * 查询答卷
     * */
    public List<AnswerEntity> queryAnswerList(AnswerEntity answerEntity){
        List<AnswerEntity> answer = answerEntityMapper.queryAnswerList(answerEntity);
        return answer;
    }
}
