package com.envc.service;

import com.envc.bean.EchartsVO;
import com.envc.common.utis.UUIDUtil;
import com.envc.dao.QuestionEntityMapper;
import com.envc.dao.entity.OptionEntity;
import com.envc.dao.entity.QuestionEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuestionService {
    @Autowired
    private QuestionEntityMapper questionEntityMapper;

    /**
     * 新增问题
     * */
    public int addQuestionInfo(QuestionEntity questionEntity){
        questionEntity.setQuestionId(UUIDUtil.getOneUUID());
        int questionResult = questionEntityMapper.insert(questionEntity);
        if(questionResult != 0){
            return 3;
        }else {
            return questionResult;
        }
    }

    @Autowired
    private OptionService optionService;
    @Autowired
    private QuestionService questionService;

    public List<QuestionEntity> queryQuestionList(QuestionEntity questionEntity){
        List<QuestionEntity> result = questionEntityMapper.queryQuestionList(questionEntity);

        for (QuestionEntity question : result) {
            String questionId = question.getQuestionId();
            List<OptionEntity> optionEntities = optionService.queryOptionList2(questionId);
            question.setOptionEntities(optionEntities);
            int questionCount =  questionService.getCountQuestion(question.getQuestionnaireId(),question.getQuestionId());
            question.setQuestionCount(questionCount);
            List<EchartsVO> vos = new ArrayList<>();

            for (OptionEntity option : optionEntities) {
                   int count =  optionService.getCountOption(question.getQuestionnaireId(),question.getQuestionId(),option.getOptionId());
                   option.setXiaoji(count);
                   option.setZonggong(questionCount);
                   int chu = count*100 / questionCount;
                   option.setBili(chu);

                EchartsVO vo = new EchartsVO(count, option.getContent());
                option.setEchartsVO(vo);
                vos.add(vo);
            }
            question.setEchartsVOS(vos);
        }
        return result;
    }

    private int getCountQuestion(String questionnaireId, String questionId) {
        return questionEntityMapper.getCountQuestion( questionnaireId,  questionId);
    }
}
