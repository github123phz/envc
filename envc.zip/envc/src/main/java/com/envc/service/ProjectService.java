package com.envc.service;

import com.envc.common.utis.UUIDUtil;
import com.envc.dao.ProjectEntityMapper;
import com.envc.dao.entity.ProjectEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // 业务处理类
public class ProjectService {
    @Autowired
    private ProjectEntityMapper projectEntityMapper;

    /**
     *项目列表查询
     **/
    public List<ProjectEntity> queryProjectList(ProjectEntity projectEntity){
        List<ProjectEntity> result = projectEntityMapper.queryProjectList(projectEntity);
        return result;
    }

    /**
     * 新增项目
     * */
    public int addProjectInfo(ProjectEntity projectEntity){
        projectEntity.setId(UUIDUtil.getOneUUID());
        int projectResult = projectEntityMapper.insert(projectEntity);
        if(projectResult !=0 ){
            return 3;
        }else {
            return projectResult;
        }
    }

    /**
     * 删除项目
     * */
    public int deleteProjectById (ProjectEntity projectEntity){
        int projectResult = projectEntityMapper.deleteProjectById(projectEntity);
        return projectResult;
    }

    /**
     * 修改项目
     * */
    public int modifyProjectInfo(ProjectEntity projectEntity){
        int projectResult = projectEntityMapper.updateByPrimaryKeySelective(projectEntity);
        return projectResult;
    }

}
