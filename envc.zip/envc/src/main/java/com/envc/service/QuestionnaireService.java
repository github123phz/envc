package com.envc.service;


import com.envc.common.utis.UUIDUtil;
import com.envc.dao.QuestionnaireEntityMapper;
import com.envc.dao.entity.QuestionEntity;
import com.envc.dao.entity.QuestionnaireEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // 业务处理类
public class QuestionnaireService {
    @Autowired
    private QuestionnaireEntityMapper questionnaireEntityMapper;
    /**
     * 新增问卷
     * */
    public int addQuestionnaireInfo(QuestionnaireEntity questionnaireEntity){
        questionnaireEntity.setQuestionnaireId(UUIDUtil.getOneUUID());
        questionnaireEntity.setIsDelete("0");
        int questionnaireResult = questionnaireEntityMapper.insert(questionnaireEntity);
        if(questionnaireResult !=0 ){
            return 3;
        }else {
            return questionnaireResult;
        }
    }

    /**
     *锁定问卷
     **/
    public List<QuestionnaireEntity> selectQuestionnaireList(QuestionnaireEntity questionnaireEntity){
        return questionnaireEntityMapper.selectQuestionnaireList(questionnaireEntity);
    }

    /**
     * 删除问卷
     * */
    public int deleteQuestionnaireById(QuestionnaireEntity questionnaireEntity){
        return questionnaireEntityMapper.deleteQuestionnaireById(questionnaireEntity);
    }

    /**
     * 查找问卷
     * */
    public List<QuestionnaireEntity> queryQuestionnaireList(QuestionnaireEntity questionnaireEntity){
        return questionnaireEntityMapper.queryQuestionnaireList(questionnaireEntity);
    }


}
