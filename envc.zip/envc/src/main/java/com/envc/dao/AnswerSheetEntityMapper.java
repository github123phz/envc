package com.envc.dao;

import com.envc.dao.entity.AnswerSheetEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
@Mapper
public interface AnswerSheetEntityMapper {
    /**
     * 查询答卷
     * */
    List<AnswerSheetEntity> queryAnswerSheetList(AnswerSheetEntity answerSheetEntity);
}
