package com.envc.dao.entity;

import com.envc.bean.EchartsVO;

import java.util.List;

public class QuestionEntity {
    private  String questionId;
    private  String questionnaireId;//外键：关联到问卷表的主键
    private  String type;//题目类型
    private  String content;//题目内容

    private int questionCount;


    private List<EchartsVO> echartsVOS;

    public List<EchartsVO> getEchartsVOS() {
        return echartsVOS;
    }

    public void setEchartsVOS(List<EchartsVO> echartsVOS) {
        this.echartsVOS = echartsVOS;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    private List<OptionEntity> optionEntities;

    public List<OptionEntity> getOptionEntities() {
        return optionEntities;
    }

    public void setOptionEntities(List<OptionEntity> optionEntities) {
        this.optionEntities = optionEntities;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getQuestionnaireId() {
        return questionnaireId;
    }

    public void setQuestionnaireId(String questionnaireId) {
        this.questionnaireId = questionnaireId;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }
}
