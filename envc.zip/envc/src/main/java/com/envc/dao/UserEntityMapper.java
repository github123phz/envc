package com.envc.dao;

import com.envc.dao.entity.UserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface UserEntityMapper {
    /**
    * 查询用户列表
    * */
    List<UserEntity> queryUserList(UserEntity userEntity);

    /**
     * 创建用户列表的基本信息
     * */
    int insert(UserEntity userEntity);

    /**
     * 根据id删除用户信息
     * */
    int deleteUserById(UserEntity userEntity);

    /**
     * 编辑用户信息
     * */
    int updateByPrimaryKeySelective(UserEntity userEntity);

    /**
     * 查询用户
     * */
    List<UserEntity> selectUserInfo(UserEntity userEntity);
}
