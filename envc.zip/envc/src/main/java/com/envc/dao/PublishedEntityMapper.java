package com.envc.dao;

import com.envc.dao.entity.PublishedEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface PublishedEntityMapper {
    /**
     * 发布问卷
     * */
    int publishQuestionnaire(PublishedEntity publishedEntity);

    /**
     * 查询问卷
     * */
    List<PublishedEntity> queryPublishedQuestionnaire(PublishedEntity publishedEntity);
}
