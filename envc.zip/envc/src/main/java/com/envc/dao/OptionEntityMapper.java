package com.envc.dao;

import com.envc.dao.entity.OptionEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface OptionEntityMapper {
    /**
     * 新增选项
     * */
    int insert(OptionEntity optionEntity);

    /**
     * 查询选项
     * */
    List<OptionEntity> queryOptionList(OptionEntity optionEntity);

    List<OptionEntity> queryOptionList2(String questionid);

    int getCountOption(@Param("questionnaireId") String questionnaireId,
                       @Param("questionId") String questionId,
                       @Param("optionId")String optionId);
}
