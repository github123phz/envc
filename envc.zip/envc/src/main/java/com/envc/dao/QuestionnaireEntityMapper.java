package com.envc.dao;

import com.envc.dao.entity.QuestionnaireEntity;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface QuestionnaireEntityMapper {

    /**
     * 新增问卷
     * */
    int insert(QuestionnaireEntity questionnaireEntity);

    /**
     * 查询问卷列表
     * */
    List<QuestionnaireEntity> queryQuestionnaireList(QuestionnaireEntity questionnaireEntity);
    List<QuestionnaireEntity> selectQuestionnaireList(QuestionnaireEntity questionnaireEntity);

    /**
     * 删除问卷
     * */
    int deleteQuestionnaireById(QuestionnaireEntity questionnaireEntity);
}
