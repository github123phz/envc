package com.envc.dao;

import com.envc.dao.entity.QuestionEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface QuestionEntityMapper {
    /**
     * 新增问题
     */
    int insert(QuestionEntity questionEntity);

    /**
     * 查询问题列表
     */
    List<QuestionEntity> queryQuestionList(QuestionEntity questionEntity);

    int getCountQuestion(@Param("questionnaireId") String questionnaireId, @Param("questionId")String questionId);
}
