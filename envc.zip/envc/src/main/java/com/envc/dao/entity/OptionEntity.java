package com.envc.dao.entity;

import com.envc.bean.EchartsVO;

public class OptionEntity {

    private  String optionId;//选项id
    private String questionId;//外键——问题
    private  String content;//选项内容

    private int xiaoji;

    private int zonggong;

    private double bili;

    private EchartsVO echartsVO;

    public EchartsVO getEchartsVO() {
        return echartsVO;
    }

    public void setEchartsVO(EchartsVO echartsVO) {
        this.echartsVO = echartsVO;
    }

    public int getZonggong() {
        return zonggong;
    }

    public void setZonggong(int zonggong) {
        this.zonggong = zonggong;
    }

    public int getXiaoji() {
        return xiaoji;
    }

    public void setXiaoji(int xiaoji) {
        this.xiaoji = xiaoji;
    }

    public double getBili() {
        return bili;
    }

    public void setBili(double bili) {
        this.bili = bili;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getOptionId() {
        return optionId;
    }

    public void setOptionId(String optionId) {
        this.optionId = optionId;
    }
}
