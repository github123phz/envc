package com.envc;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.envc.dao")
public class EnvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(EnvcApplication.class, args);
    }

}
