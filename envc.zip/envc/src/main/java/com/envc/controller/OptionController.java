package com.envc.controller;

import com.envc.bean.HttpResponseEntity;
import com.envc.dao.entity.OptionEntity;
import com.envc.service.OptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

@RestController
public class OptionController {
    @Autowired
    private OptionService optionService;
    /**
     * 新增选项
     * */
    @RequestMapping(value = "/addOptionInfo", method = RequestMethod.POST, headers =  "Accept=application/json")
    public HttpResponseEntity addOption(@RequestBody OptionEntity OptionEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            int result = optionService.addOptionInfo(OptionEntity);
            if(result!=0){
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(result);
                httpResponseEntity.setMessage("创建成功");
            } else{
                httpResponseEntity.setCode("0");
                httpResponseEntity.setData(0);
                httpResponseEntity.setMessage("创建失败");
            }

        } catch (Exception e){
            System.out.println(e.getMessage()); // 输出异常信息
            e.printStackTrace(); // 打印异常堆栈信息 记录异常发生的记录
        }
        return httpResponseEntity;
    }

    /**
     * 查询选项
     * */
    @RequestMapping(value = "/queryOptionList", method = RequestMethod.POST, headers =  "Accept=application/json")
    public HttpResponseEntity queryOptionList(@RequestBody OptionEntity optionEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<OptionEntity> hasOption = optionService.queryOptionList(optionEntity);
            if(CollectionUtils.isEmpty(hasOption)){
                httpResponseEntity.setCode("0");
                httpResponseEntity.setMessage("无选项信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(hasOption);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }

}
