package com.envc.controller;

import com.envc.bean.HttpResponseEntity;
import com.envc.dao.entity.AnswerSheetEntity;
import com.envc.service.AnswerSheetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AnswerSheetController {
    @Autowired
    AnswerSheetService answerSheetService;

    /**
     * 查询答卷
     * */
    @RequestMapping(value = "/queryAnswerSheetList", method = RequestMethod.POST, headers = "Accept=application/json")
    public HttpResponseEntity queryAnswerSheetList(@RequestBody AnswerSheetEntity answerSheetEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<AnswerSheetEntity> hasAnswerSheet = answerSheetService.queryAnswerSheetList(answerSheetEntity);
            if(CollectionUtils.isEmpty(hasAnswerSheet)){
                httpResponseEntity.setCode("0");
                httpResponseEntity.setMessage("无问卷信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(hasAnswerSheet);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }
}
