package com.envc.controller;

import com.envc.bean.HttpResponseEntity;
import com.envc.dao.entity.QuestionEntity;
import com.envc.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class QuestionController {
    @Autowired
    private QuestionService questionService;
    /**
     * 新增问题
     * */
    @RequestMapping(value = "/addQuestionInfo",method = RequestMethod.POST, headers =  "Accept=application/json")
    public HttpResponseEntity addQuestion(@RequestBody QuestionEntity questionEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            int result = questionService.addQuestionInfo(questionEntity);
            if(result!=0){
                httpResponseEntity.setCode(questionEntity.getQuestionId());
                httpResponseEntity.setData(result);
                httpResponseEntity.setMessage("创建成功");
            } else{
                httpResponseEntity.setCode("0");
                httpResponseEntity.setData(0);
                httpResponseEntity.setMessage("创建失败");
            }

        } catch (Exception e){
            System.out.println(e.getMessage()); // 输出异常信息
            e.printStackTrace(); // 打印异常堆栈信息 记录异常发生的记录
        }
        return httpResponseEntity;
    }

    /**
     * 查询问题列表
     * */
    @RequestMapping(value = "/queryQuestionList",method = RequestMethod.POST, headers = "Accept=application/json")
    public HttpResponseEntity queryQuestionList(@RequestBody QuestionEntity questionEntity){
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<QuestionEntity> result = questionService.queryQuestionList(questionEntity);
            if(CollectionUtils.isEmpty(result)){
                httpResponseEntity.setCode("0");
                httpResponseEntity.setMessage("无项目信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(result);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }

    /**
     * 查询问题列表
     * */
    @RequestMapping(value = "/queryQuestionList2",method = RequestMethod.POST, headers = "Accept=application/json")
    public HttpResponseEntity queryQuestionList2(@RequestBody QuestionEntity questionEntity,String time){
        System.out.println(time);
        HttpResponseEntity httpResponseEntity = new HttpResponseEntity();
        try {
            List<QuestionEntity> result = questionService.queryQuestionList(questionEntity);
            if(CollectionUtils.isEmpty(result)){
                httpResponseEntity.setCode("0");
                httpResponseEntity.setMessage("无项目信息");
            }else {
                httpResponseEntity.setCode("666");
                httpResponseEntity.setData(result);
                httpResponseEntity.setMessage("查询成功");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return httpResponseEntity;
    }

}
