package com.envc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;

@Controller
public class TongjiController {
    @RequestMapping(value = "/tongji/index")
    public String queryProjectList(String shijuanid){
        System.out.println("试卷id="+shijuanid);

        return "/pages/tongji/index";
    }
}
