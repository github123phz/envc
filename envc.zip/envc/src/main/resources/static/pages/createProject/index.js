onload = () => {
  $('#headerUsername').text($util.getItem('userInfo')[0].username)
  $('#headerDivB').text('创建项目')
}

function getCurrentDateTime() {
  const currentDate = new Date();
  return currentDate;
}


const handleCreateProject = () => {
  const currentDateTime = getCurrentDateTime();
  console.log(currentDateTime);

  let params = {
    userId:$util.getItem('userInfo')[0].id,
    projectName: $('#projectName').val(),
    projectContent: $('#projectDescribe').val(),
    createdBy: $util.getItem('userInfo')[0].username,
    creationDate:currentDateTime,
    lastUpdatedBy: $util.getItem('userInfo')[0].username,
    lastUpdateDate:currentDateTime,
  }
  if (!params.projectName) return alert('项目名称不能为空！')
  if (!params.projectContent) return alert('项目描述不能为空！')
  $.ajax({
    url: API_BASE_URL + '/addProjectInfo',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success() {
      alert('创建成功！')
      location.href = "/pages/questionnaire/index.html"
    }
  })
}
