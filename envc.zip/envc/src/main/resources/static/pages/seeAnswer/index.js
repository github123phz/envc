onload = () => {
    let questionnaireId = $util.getPageParam('seeAnswer_questionnaireId')
    let answerName = $util.getPageParam('seeAnswer_answerName')
    let answerTime = $util.getPageParam('seeAnswer_answerTime')
    console.log($util.getItem('data'))
    $('#title').text($util.getItem('data')[0].title)
    $('#description').text($util.getItem('data')[0].description)
    loadQuestion(questionnaireId, answerName, answerTime)
}
const loadQuestion = (questionnaireId, answerName, answerTime) => {
    let params = {
        questionnaireId: questionnaireId
    };
    $.ajax({
        url: API_BASE_URL + '/queryQuestionList',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        success(res) {
            $('#problem').html('');
            res.data.forEach((item) => {
                let questionId = item.questionId;
                let questionType = item.type;
                let questionTitle = `${questionType === "单选题" ? "单选题" : questionType === "多选题" ? "多选题" : "填空题"} ${item.content}`;
                let questionHtml = `
                    <div class="question" id="${questionId}" data-type="1" data-problemIndex="1">
                        <div class="top">
                            <span class="question-title" id="questionTitle">${questionTitle}</span>
                            <span class="must-answer" id="mustAnswer" style="color: red">必答题</span>
                        </div>
                    </div>
                `;
                $('#problem').append(questionHtml);
//查询答案
                let params = {
                    questionId: questionId,
                    questionnaireId: questionnaireId,
                    answerName: answerName,
                    answerTime: answerTime
                };

                $.ajax({
                    url: API_BASE_URL + '/queryAnswerList',
                    type: "POST",
                    data: JSON.stringify(params),
                    dataType: "json",
                    contentType: "application/json",
                    success(res) {
                        let answer = res.data;
                        loadOption(questionId, questionType, answer);
                    }
                });
            });
        }
    });
};


const loadOption = (questionId, questionType, answer) => {
    let params = {
        questionId: questionId
    };
    console.log(answer);
    $.ajax({
        url: API_BASE_URL + '/queryOptionList',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        success(res) {
            let questionElement = $('#' + questionId);
            res.data.forEach(item => {
                let isChecked = false;

                if (questionType === "单选题") {
                    isChecked = answer[0].content === item.content;
                } else if (questionType === "多选题") {
                    isChecked = answer.some(ans => ans.content === item.content);
                }

                let inputType = questionType === "单选题" ? "radio" : "checkbox";

                questionElement.append(`
                    <div style="display: flex; align-items: center; margin-bottom: 3px;">
                        <label class="${inputType}-inline">
                            <input type="${inputType}" name="chooseTerm_${questionId}" ${isChecked ? "checked" : ""}>${item.content}
                        </label>
                    </div>
                `);
            });
            $('#problem').append(questionElement);
        }
    });
}


const back=()=>{
    location.href = "/pages/seeQuestionnaire/index.html"
}
