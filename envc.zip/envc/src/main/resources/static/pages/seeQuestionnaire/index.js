onload = () => {
    $('#headerUsername').text($util.getItem('userInfo')[0].username)
    handleHeaderLoad()
    fetchAnswerSheetList()
}

const fetchAnswerSheetList=() =>{
    let params={
        projectId:$util.getPageParam('onLookQuestionnaire'),
        answerName:$('#answerName').val()
    }
    $.ajax({
        url: API_BASE_URL + '/queryAnswerSheetList',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        success(res){
            $('#table #tbody').html('')
            console.log(res.data)
            res.data.map((item, index) => {
                $('#table #tbody').append(`
          <tr>
            <td>${index + 1}</td>
            <td>${item.title}</td>
            <td>${item.answerName}</td>
            <td>${item.answerTime}</td>
            <td>
              <button type="button" class="btn btn-link btn-red" onclick="CheckQuestionnaire('${item.questionnaireId}','${item.answerName}','${item.answerTime}')">明细</button>
            </td>
          </tr>
        `)
            })
        }
    })
}
const CheckQuestionnaire = (questionnaireId,answerName, answerTime)=>{
    $util.setPageParam('seeAnswer_questionnaireId', questionnaireId)
    $util.setPageParam('seeAnswer_answerName', answerName)
    $util.setPageParam('seeAnswer_answerTime', answerTime)
    let params={
        questionnaireId:questionnaireId
    }
    $.ajax({
        url: API_BASE_URL + '/selectQuestionnaireList',
        type: "POST",
        data: JSON.stringify(params),
        dataType: "json",
        contentType: "application/json",
        success(res){
            $util.setItem('data',res.data)
            location.href = "/pages/seeAnswer/index.html"
        }
    })
}