onload = () => {
  let questionnaireId = $util.getPageParam('QuestionnaireId')
  $('#title').text($util.getItem('QuestionnaireData')[0].title)
  $('#description').text($util.getItem('QuestionnaireData')[0].description)
  loadQuestion(questionnaireId)
}
const loadQuestion = (questionnaireId) => {
  let params = {
    questionnaireId: questionnaireId
  };
  $.ajax({
    url: API_BASE_URL + '/queryQuestionList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      $('#problem').html('');
      res.data.forEach((item) => {
        let questionId = item.questionId;
        let questionType = item.type;
        let questionTitle = `${questionType === "单选题" ? "单选题" : questionType === "多选题" ? "多选题" : "填空题"} ${item.content}`;
        let questionHtml = `
                    <div class="question" id="${questionId}" data-type="1" data-problemIndex="1">
                        <div class="top">
                            <span class="question-title" id="questionTitle">${questionTitle}</span>
                            <span class="must-answer" id="mustAnswer" style="color: red">必答题</span>
                        </div>
                    </div>
                `
        $('#problem').append(questionHtml)
        loadOption(questionId, questionType)
      })
    }
  })
}


const loadOption = (questionId, questionType) => {
  let params = {
    questionId: questionId
  };
  $.ajax({
    url: API_BASE_URL + '/queryOptionList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      let questionElement = $('#' + questionId);
      res.data.forEach(item => {
        if (questionType === "单选题") {
            questionElement.append(`
                            <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                <label class="radio-inline">
                                    <input type="radio" name="chooseTerm_${questionId}">${item.content}
                                </label>
                            </div>
                        `);
        } else if (questionType === "多选题") {
            questionElement.append(`
                            <div style="display: flex; align-items: center; margin-bottom: 3px;">
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="chooseTerm">${item.content}
                                </label>
                            </div>
                        `);
        } else if (questionType === "填空题") {
          $('#problem').append(`
                        <textarea class="form-control" placeholder="请输入" rows="4" style="width: 70%;"></textarea>
                    `);
        }
      });
      $('#problem').append(questionElement);
    }
  });
}

const back=()=>{
  location.href = "/pages/seeProject/index.html"
}
