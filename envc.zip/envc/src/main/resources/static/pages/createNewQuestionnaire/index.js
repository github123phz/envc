onload = () => {
  $('#headerUsername').text($util.getItem('userInfo')[0].username)
  $('#headerDivB').text('创建调查问卷')
  $('#startTime').datetimepicker({
    language: 'zh-CN', // 显示中文
    format: 'yyyy-mm-dd', // 显示格式
    minView: "month", // 设置只显示到月份
    initialDate: new Date(), // 初始化当前日期
    autoclose: true, // 选中自动关闭
    todayBtn: true // 显示今日按钮
  })
  $('#endTime').datetimepicker({
    language: 'zh-CN', // 显示中文
    format: 'yyyy-mm-dd', // 显示格式
    minView: "month", // 设置只显示到月份
    initialDate: new Date(), // 初始化当前日期
    autoclose: true, // 选中自动关闭
    todayBtn: true // 显示今日按钮
  })
}


const createQuestionnaire = () => {
  console.log($util.getItem('userInfo'))
  let params = {
    projectId: $util.getPageParam('chooseId'),
    type: $util.getPageParam('type'),
    title:$('#surveyName').val(),
    description:$("#surveyDescription").val(),
    createdBy:$util.getItem('userInfo')[0].username,
    creationDate:new Date(),
    lastUpdatedBy:$util.getItem('userInfo')[0].username,
    lastUpdateDate:new Date(),
    userID:$util.getItem('userInfo')[0].id,
    startTime:$('#start').val(),
    endTime:$('#end').val()
  }
  if($('#surveyName').val()==null||$("#surveyName").val()=="") return alert('请输入问卷名称！')
  if($("#surveyDescription").val()==null||$("#surveyDescription").val()=="") return alert('请输入问卷描述！')
  $.ajax({
    url: API_BASE_URL + '/addQuestionnaireInfo',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      if (res.code!=='0') {
        $util.setPageParam('questionnaireId', res.code)
        location.href = "/pages/designQuestionnaire/index.html"
      } else {
        alert(res.message)
      }
    }
  })
}
