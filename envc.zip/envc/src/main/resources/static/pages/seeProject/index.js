onload = () => {
  $('#headerDivB').text('项目详情')

  projectId = $util.getPageParam('seeProject')
  console.log(projectId, 'projectId')
  fetchProjectInfo(projectId)
  fetchQuestionnaireList(projectId)
}
let projectId
const fetchProjectInfo = (id) => {
  let params = {
    id:id
  }
  $.ajax({
    url: API_BASE_URL + '/queryProjectList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      let info = res.data[0]
      $('#projectName').text(info.projectName)
      $('#createTime').text(info.creationDate)
      $('#personInCharge').text(info.createdBy)
      $('#projectDescription').text(info.projectContent)
    }
  })
}



const fetchQuestionnaireList = (id) => {
  let params = {
    createdBy: $util.getItem('userInfo')[0].username,//需要传一下用户名
    projectId:id
  }
  $.ajax({
    url: API_BASE_URL + '/queryQuestionnaireList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      $('#table #tbody').html('')
      console.log(res.data)
      res.data.map((item, index) => {
        $('#table #tbody').append(`
          <tr>
            <td>${index+1}</td>
            <td>${item.title}</td>
            <td>${item.startTime}</td>
            <td>
              <button type="button" class="btn btn-link" onclick="onEditQuestionnaire('${item.questionnaireId}')">预览</button>
              <button type="button" class="btn btn-link" onclick="onPublishQuestionnaire('${item.questionnaireId}')">发布</button>
              <button type="button" class="btn btn-link btn-red" onclick="onDelQuestionnaire('${item.questionnaireId}')">删除</button>
              <button type="button" class="btn btn-link btn-red"  onclick="onTongji('${item.questionnaireId}','${item.title}')"  )">统计</button>
            </td>
          </tr>
        `)
      })
    }
  })
}


function onTongji(shijuanid,shijuantitle){
     window.location="/pages/tongji/index.html?shijuanid="+shijuanid+"&shijuantitle="+shijuantitle;
}
const onDelQuestionnaire = (pid) => {
  let state = confirm("确认删除该问卷吗？")
  if (state) {
    let params = {
      questionnaireId:pid
    }
    //alert(JSON.stringify(params))
    $.ajax({
      url: API_BASE_URL + '/deleteQuestionnaireById',
      type: "POST",
      data: JSON.stringify(params),
      dataType: "json",
      contentType: "application/json",
      success(res) {
        alert(res.message)
        fetchQuestionnaireList(projectId)
      }
    })
  }

}

const onEditQuestionnaire = (id) => {
  $util.setPageParam('QuestionnaireId', id)
  let params={
    questionnaireId:id
  }
  $.ajax({
    url: API_BASE_URL + '/selectQuestionnaireList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      $util.setItem('QuestionnaireData',res.data)
      location.href = "/pages/answerSheet/index.html"
    }
  })
}

const onPublishQuestionnaire=(questionnaireId)=>{
  let params={
    questionnaireId:questionnaireId
  }
  $.ajax({
    url: API_BASE_URL + '/publishQuestionnaire',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      onGetPublishedQuestionnaire(res.data)
    }
  })
}

const onGetPublishedQuestionnaire=(id)=>{
  let params={
    id:id
  }
  $.ajax({
    url: API_BASE_URL + '/queryPublishedQuestionnaire',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      alert("发布成功！问卷链接为" + res.data[0].link)
      onEditQuestionnaire($util.getPageParam('QuestionnaireId'))
    }
  })
}