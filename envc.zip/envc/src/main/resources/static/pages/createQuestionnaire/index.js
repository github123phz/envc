onload = () => {
  $('#headerUsername').text($util.getItem('userInfo')[0].username)
  $('#headerDivB').text('创建问卷')
  let projectId = $util.getPageParam('createQuestionnaire')
  gettype(projectId)
}
const gettype = (id) => {
  let params = {
    createdBy: $util.getItem('userInfo')[0].username
  }
  $.ajax({
    url: API_BASE_URL + '/queryProjectList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      let tmp = res.data;//将表单信息提取
      for (let i = 0; i < tmp.length; i++) {
        if (id === tmp[i].id) {
          $('#selectproject').append(new Option(tmp[i].projectName, tmp[i].id, true));
        }else {
          $('#selectproject').append(new Option(tmp[i].projectName, tmp[i].id, false));
        }
      }
    }
  })

}
const importHistoryQuestionnaire = () => {
  $('#divider').css('display', 'flex')
  $('#templateB').html('')
  $('#templateB').append(`
    <div class="template-item">
      <div class="item-t">
        <img class="img" src="../../static/images/blank_template.png">
        <div>
          <div class="title">测试</div>
          <div>页面测试数据</div>
        </div>
      </div>
      <div class="item-b">
        <button type="button" class="btn btn-default">导 入</button>
      </div>
    </div>
  `)
}

const surveyTypeTemplate = () => {
  $('#divider').css('display', 'flex')
  $('#templateB').html('')
  $('#templateB').append(`
    <div class="template-item">
      <div class="item-t">
        <img class="img" src="../../static/images/blank_template.png">
        <div>
          <div class="title">创建模板</div>
          <div>题库抽题，限时作答，成绩查询，自动阅卷</div>
        </div>
      </div>
      <div class="item-b">
        <button type="button" class="btn btn-default" onclick="createTemplate()">创 建</button>
      </div>
    </div>
    <div class="template-item">
      <div class="item-t">
        <img class="img" src="../../static/images/blank_template.png">
        <div>
          <div class="title">测试</div>
          <div></div>
        </div>
      </div>
      <div class="item-b">
        <button type="button" class="btn btn-default" onclick="handleEdit()" style="margin-right: 10px;">编 辑</button>
        <button type="button" class="btn btn-default">导 入</button>
      </div>
    </div>
  `)
}
const onCreateTemplate = () => {
  let index=document.getElementById("selectLeo").selectedIndex;//获取当前选择项的索引
  $util.setPageParam('type',document.getElementById("selectLeo").options[index].text)
  let project_index=document.getElementById("selectproject").selectedIndex;
  let params = {
    createdBy: $util.getItem('userInfo')[0].username,
  }
  $.ajax({
    url: API_BASE_URL + '/queryProjectList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      let tmp = res.data;//将表单信息提取
      for (let i = 0; i < tmp.length; i++) {
        if (document.getElementById('selectproject').options[project_index].text === tmp[i].projectName) {
          $util.setPageParam('chooseId', tmp[i].id)
        }
      }
    }
  })
  location.href = "/pages/createNewQuestionnaire/index.html";
}
function getSelectValue(sel){
  var select = null;
  for(var i = 0; i < sel.length; i++){
    if (sel[i].selected == true) {
      select = sel[i].value;
      alert(select)
    }
  }
  return select;
}

const createTemplate = () => {
  $('#createTemplateModal').modal('show')
}

const handleEdit = () => {
  open('/pages/designQuestionnaire/index.html')
}


