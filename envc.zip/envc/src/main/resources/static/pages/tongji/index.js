onload = () => {
  $('#headerDivB').text('问卷统计');
  //shijuanid = $util.getPageParam('shijuanid');
  let shijuantitle = getUrlParam("shijuantitle");//参数是中文则用这个方法
  $('#shijuantitle').text(shijuantitle);

  shijuanid = getUrlParam("shijuanid");//参数是中文则用这个方法
  loadQuestion(shijuanid);
}
let shijuanid;

let resdata=null;

const loadQuestion = (questionnaireId) => {
  let params = {
    questionnaireId: questionnaireId
  };
  $.ajax({
    url: API_BASE_URL + '/queryQuestionList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      resdata = res.data;
      $('#problem').html('');
      res.data.forEach((item,index) => {
        index++;
        let questionId = item.questionId;
        let opslength = item.optionEntities.length;

        let ops='';
        for (let i = 0; i < opslength; i++) {
          let ophtml=' <tr>\n' +
              '               <td>'+item.optionEntities[i].content+'</td>\n' +
              '               <td>'+item.optionEntities[i].xiaoji+'</td>\n' +
              '               <td>\n' +
              '                 <div class="progress">\n' +
              '                   <div class="progress-bar" role="progressbar" aria-valuenow="'+item.optionEntities[i].bili+'" aria-valuemin="0" aria-valuemax="100" style="width: '+item.optionEntities[i].bili+'%;">\n' +
              '                     '+item.optionEntities[i].bili+'%\n' +
              '                   </div>\n' +
              '                 </div>\n' +
              '               </td>\n' +
              '             </tr>';
          ops=ops+ophtml;
        }
        let ophtml1=' <tr>\n' +
                      '               <td>'+'本题有效填写人次'+'</td>\n' +
                      '               <td>'+item.questionCount+'</td>\n' +
                      '               <td>\n' + '' +
                      '               </td>\n' +
                      '             </tr>';
        ops=ops+ophtml1;

        let questionHtml = ' <div class="biaoge">\n' +
            '           <table class="table table-bordered">\n' +
            '             <caption><strong>第'+index+'题：</strong>'+item.content+'\n' +
            '\n' +
            '               <span style="float: right;color: blue;font-weight: bold;"><a href="index-back.html">同类问题统计</a></span>\n' +
            '             </caption>\n' +
            '             <thead>\n' +
            '             <tr style="background-color:rgba(232,229,229,0.81);">\n' +
            '               <th  width="110">选项</th>\n' +
            '               <th width="10">小计</th>\n' +
            '               <th  width="100">比例</th>\n' +
            '             </tr>\n' +
            '             </thead>\n' +
            '             <tbody>\n' +
                             ops+
            '             </tbody>\n' +
            '           </table>\n' +
            '           <div style="float: right;">\n' +
            '\n' +
            '             <div class="btn-group" role="group" >\n' +
            '               <button type="button" onclick="biaoge()" class="btn btn-default"><span class="glyphicon  glyphicon-list"></span>表格</button>\n' +
            '               <button type="button" qid='+questionId+'  onclick="bintu('+questionId+')" class="btn btn-default"><span class="glyphicon  glyphicon-adjust"></span>饼状</button>\n' +
            '               <button type="button"  qid='+questionId+'  onclick="yuanhuan('+questionId+')" class="btn btn-default"><span class="glyphicon  glyphicon-repeat"></span>圆环</button>\n' +
            '               <button type="button" qid='+questionId+'  onclick="zhuzhuang('+questionId+')"  class="btn btn-default"><span class="glyphicon  glyphicon-stats"></span>柱状</button>\n' +
            '               <button type="button" qid='+questionId+'  onclick="tiaoxing('+questionId+')" class="btn btn-default"><span class="glyphicon  glyphicon-barcode"></span>条形</button>\n' +
            '               <button type="button"  qid='+questionId+'  onclick="zhexian('+questionId+')" class="btn btn-default"><span class="glyphicon  glyphicon-saved"></span>折线</button>\n' +
            '             </div>\n' +
            '           </div>\n' +
            '\n' +
            '\n' +
            '         </div>';
        questionHtml = questionHtml.replace('href="index-back.html"', `href="index-back${index}.html"`);
        $('#container').append(questionHtml)

      })
    }
  })
}

const fetchQuestionnaireList = (id) => {
  let params = {
    createdBy: $util.getItem('userInfo')[0].username,//需要传一下用户名
    projectId:id
  }
  $.ajax({
    url: API_BASE_URL + '/queryQuestionnaireList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res) {
      $('#table #tbody').html('')
      console.log(res.data)

    }
  })
}

function onTongji(shijuanid){
     window.location="/pages/tongji/index?shijuanid="+shijuanid;
}

const onDelQuestionnaire = (pid) => {
  let state = confirm("确认删除该问卷吗？")
  if (state) {
    let params = {
      questionnaireId:pid
    }
    //alert(JSON.stringify(params))
    $.ajax({
      url: API_BASE_URL + '/deleteQuestionnaireById',
      type: "POST",
      data: JSON.stringify(params),
      dataType: "json",
      contentType: "application/json",
      success(res) {
        alert(res.message)
        fetchQuestionnaireList(projectId)
      }
    })
  }

}

const onEditQuestionnaire = (id) => {
  $util.setPageParam('QuestionnaireId', id)
  let params={
    questionnaireId:id
  }
  $.ajax({
    url: API_BASE_URL + '/selectQuestionnaireList',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      $util.setItem('QuestionnaireData',res.data)
      location.href = "/pages/answerSheet/index.html"
    }
  })
}

const onPublishQuestionnaire=(questionnaireId)=>{
  let params={
    questionnaireId:questionnaireId
  }
  $.ajax({
    url: API_BASE_URL + '/publishQuestionnaire',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      onGetPublishedQuestionnaire(res.data)
    }
  })
}

const onGetPublishedQuestionnaire=(id)=>{
  let params={
    id:id
  }
  $.ajax({
    url: API_BASE_URL + '/queryPublishedQuestionnaire',
    type: "POST",
    data: JSON.stringify(params),
    dataType: "json",
    contentType: "application/json",
    success(res){
      alert("发布成功！问卷链接为" + res.data[0].link)
      onEditQuestionnaire($util.getPageParam('QuestionnaireId'))
    }
  })
}

function getUrlParam(param){
  // 用该属性获取页面 URL 地址从问号 (?) 开始的 URL（查询部分）
  var url = window.location.search;
  // 正则筛选地址栏
  var reg = new RegExp("(^|&)"+ param +"=([^&]*)(&|$)");
  // 匹配目标参数
  var result = url.substr(1).match(reg);
  //返回参数值
  return result ? decodeURIComponent(result[2]) : null;
}

